'use strict';
const fs = require('fs');
const edit = (file, pairs) => {
  let t = fs.readFileSync(file, 'utf8');
  for (const [a, b] of pairs) { if (!t.includes(a)) throw new Error(`${file} missing: ${a.slice(0, 80)}`); t = t.replace(a, () => b); }
  fs.writeFileSync(file, t);
};
// 1. DPAPI: Set-Content leaves a trailing CRLF, which ConvertTo-SecureString rejects; the text is trimmed before conversion.
edit('dpapi-key.cjs', [
  ["  '$s = Get-Content -Raw $f | ConvertTo-SecureString; ' +", "  '$s = (Get-Content -Raw $f).Trim() | ConvertTo-SecureString; ' +"],
]);
// 2. state store: a temporary file is removed only if THIS call created it (an exclusive-create collision must not delete someone else's file)
edit('state-store.cjs', [
  ["    let fd;\n    try {\n      fd = fs.openSync(tmp, 'wx', 0o600);\n", "    let fd; let created = false;\n    try {\n      fd = fs.openSync(tmp, 'wx', 0o600); created = true;\n"],
  ["      try { fs.unlinkSync(tmp); } catch { /* ignore */ }\n      throw new StateError(`state write failed before completion", "      if (created) { try { fs.unlinkSync(tmp); } catch { /* ignore */ } }\n      throw new StateError(`state write failed before completion"],
]);
console.log('patched');
