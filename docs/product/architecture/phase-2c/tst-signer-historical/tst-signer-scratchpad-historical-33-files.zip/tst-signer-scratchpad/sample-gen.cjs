'use strict';
// Generates redacted sample output: (1) a pinned-config sample for a throwaway fake F; (2) a mocked mint preview.
const crypto = require('crypto');
const H = require('./test/helpers.cjs');
const { makeDeploymentConfigText } = require('./make-deployment-config.cjs');
const { S, core } = H;
const redactIds = (s) => s.replace(/\bC[A-Z2-7]{55}\b/g, 'C<predicted-contract-id>').replace(/\bG[A-Z2-7]{55}\b/g, (m) => (m === core.APPROVED.C ? m : m === core.APPROVED.D ? m : 'G<fake-F-for-the-sample>'));
(async () => {
  const fakeF = S.Keypair.random().publicKey();
  const text = makeDeploymentConfigText(S, fakeF);
  console.log('=== deployment-config.json (sample, throwaway fake F)');
  console.log(redactIds(text.replace(/"saltHex": "[0-9a-f]{64}"/, '"saltHex": "<64 hex characters>"')));
  console.log('=== pinned.cjs would then contain: PINNED_CONFIG_SHA256 = "' + crypto.createHash('sha256').update(Buffer.from(text, 'utf8')).digest('hex').replace(/./g, (c, i) => (i < 8 ? c : '.')) + '" (shown truncated)');
  const m = H.makeDeps('mint-C', { cfgUsed: H.cfgUnpinned });
  const out = []; m.deps.log = (s) => out.push(s);
  await core.preview(m.deps, H.cfgUnpinned, 'mint-C');
  console.log('\n=== preview mint-C (MOCKED RPC, unpinned sample config)');
  console.log(redactIds(out.join('\n')).replace(H.F, 'G<fake-F-for-the-sample>'));
})();
