'use strict';
// Finalizes the revision-4 documentation: fills the result placeholders, copies the final sources, regenerates SHA256SUMS.txt
// and appends the three revision-4 sections. Reads only the signer directory; writes only the documentation directory.
const fs = require('fs'); const path = require('path'); const crypto = require('crypto');
const DOCS = 'C:/Users/Ebubechi/Documents/codes/scf/tobin-protocol/tobin/docs/product/architecture/phase-2c';
const SRC = path.join(DOCS, 'tst-signer-source');
const FILES = ['tst-signer-core.cjs', 'tst-signer.cjs', 'dpapi-key.cjs', 'sdk-loader.cjs', 'state-store.cjs', 'pinned.cjs', 'make-deployment-config.cjs',
  'mutate.cjs', 'dryrun-live.cjs', 'evidence.cjs', 'windows-validation.cjs', 'acl-experiment.cjs',
  'test/helpers.cjs', 'test/tst-signer.test.cjs', 'test/hardening.test.cjs', 'test/submission.test.cjs', 'test/expiry.test.cjs', 'test/windows.test.cjs'];
const sha = (f) => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');

// copies + checksums
const lines = [];
for (const f of FILES) {
  const dest = path.join(SRC, path.basename(f) + '.txt');
  fs.copyFileSync(f, dest);
  const h = sha(f); if (h !== sha(dest)) throw new Error('copy differs: ' + f);
  lines.push(`${h}  ${f}`);
}
fs.writeFileSync(path.join(SRC, 'SHA256SUMS.txt'), [
  '# SHA-256 of the signer files (working copies in the scratchpad == the .txt copies in this directory)',
  '# Computed 2026-11-04 after revision 4 (final review and Windows validation). Each .txt copy was verified to hash identically to its working file.',
  '# One-off edit scripts (patch-*.cjs), sample generators and logs are not part of the signer and are not listed.',
  '# Verify in PowerShell: Get-FileHash -Algorithm SHA256 <file> and compare with the line below.',
  '# This list is only independent once a copy lives somewhere the signer\'s directory cannot reach (see the security review).',
  ...lines, ''].join('\n'));

// fill the revision-4 sections
const MUT = '85 mutants, all killed';
const NOTES = 'The full run of 86 mutants (baseline 106 green) killed 82; one survived (the rule that rejects contradictory network-time evidence had no test of its own; a test was added) and three definitions no longer matched the changed source (one obsolete mutant removed, two re-defined). Those mutants were re-run against a green baseline of 107 and all were killed. New mutants cover: expiry from network time (each of the five conditions, the status check, and a reverted local-clock rule), the rejected-attempt block (no evidence, chain shows inclusion, RPC down, lift not recorded), ACL judgement (inheritance, owner, rule count, other principals, inherited rules, rights, exit code trusted, icacls failure ignored, verdict ignored), permission steps in the state writer (never applied, failure ignored, final file not verified), cleanup of a file not created by the call, and the two DPAPI defects (the newline trim and the buffer zeroing). 15 mutants run against the Windows suite, the rest against the offline suites.';
const fill = (s) => s.split('{{MUT_SUMMARY}}').join(MUT).split('{{MUT_NOTES}}').join(NOTES)
  .split('106 tests, all passing').join('107 tests, all passing').split('25 core rules, 31 hardening, 25 submission reconciliation, 12 expiry reconciliation, 13 Windows validation').join('25 core rules, 31 hardening, 25 submission reconciliation, 13 expiry reconciliation, 13 Windows validation')
  .split('against a verified green baseline of 106').join('against a verified green baseline (106 for the full run, 107 for the targeted re-run after one test was added)')
  .split('# 106 tests').join('# 107 tests').split('New, 12 tests').join('New, 13 tests').split('**New**, 12 tests').join('**New**, 13 tests')
  .split('Tests: 106 of 106 pass (25 + 31 + 25 + 12 + 13).').join('Tests: 107 of 107 pass (25 + 31 + 25 + 13 + 13).')
  .split('now 18 files: the previous 14').join('now 18 files: the previous 14')
  .split('`patch-rev4.cjs`, `patch-rev4b.cjs`, `patch-tests-rev4.cjs`, `patch-expiry-tests.cjs`, `patch-mutate-rev4.cjs`').join('`patch-rev4.cjs`, `patch-rev4b.cjs`, `patch-rev4c.cjs`, `patch-tests-rev4.cjs`, `patch-expiry-tests.cjs`, `patch-mutate-rev4.cjs`, `finalize-docs-rev4.cjs`');
const append = (doc, part) => { const p = path.join(DOCS, doc); fs.writeFileSync(p, fs.readFileSync(p, 'utf8') + fill(fs.readFileSync(part, 'utf8'))); };
append('tst-signer-security-review.md', 'rev4-review.part');
append('tst-signer-usage-guide.md', 'rev4-guide.part');
append('tst-signer-hardening-change-report.md', 'rev4-change.part');
for (const p of ['rev4-review.part', 'rev4-guide.part', 'rev4-change.part']) fs.unlinkSync(p);
console.log('docs finalized;', FILES.length, 'files checksummed');
