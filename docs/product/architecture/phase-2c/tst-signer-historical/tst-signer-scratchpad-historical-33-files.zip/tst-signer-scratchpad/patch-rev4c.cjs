'use strict';
const fs = require('fs');
// 1. a test that exercises the "latest earlier than oldest" rule on its own
let t = fs.readFileSync('test/expiry.test.cjs', 'utf8');
const anchor = "test('windowClosedByNetwork: malformed network-time evidence never closes the window', () => {";
if (!t.includes(anchor)) throw new Error('anchor');
t = t.replace(anchor, () => `test('windowClosedByNetwork: contradictory evidence (latest ledger earlier than oldest) never closes the window, even when every other condition holds', () => {
  // a record with an early window so that "latest after the window" and "history before the submission" both hold
  const now = realNow(); const r = { submittedAt: new Date((now - 2000) * 1000).toISOString(), maxTime: 100 };
  const consistent = { status: 'NOT_FOUND', latestLedgerCloseTime: '200', oldestLedgerCloseTime: '10' };
  assert.equal(core.windowClosedByNetwork(r, consistent, now).closed, true);
  const contradictory = { status: 'NOT_FOUND', latestLedgerCloseTime: '200', oldestLedgerCloseTime: '300' };
  const v = core.windowClosedByNetwork(r, contradictory, now);
  assert.equal(v.closed, false); assert.match(v.why, /inconsistent/);
});

` + anchor);
fs.writeFileSync('test/expiry.test.cjs', t);

// 2. harness: drop the obsolete mutant, re-define two stale ones, add an optional label filter for targeted re-runs
let m = fs.readFileSync('mutate.cjs', 'utf8');
const dropLine = (needle) => { const i = m.indexOf(needle); if (i < 0) throw new Error('missing ' + needle); const s = m.lastIndexOf('\n', i) + 1; const e = m.indexOf('\n', i) + 1; m = m.slice(0, s) + m.slice(e); };
dropLine('reconcile: expires too early');
dropLine('blocking: rejected attempt does not block a new one');
dropLine('state: blocking window never applies');
const add = [
  `  [C, ${JSON.stringify('  if (blocker) {\n    // a rejected envelope')}, ${JSON.stringify('  if (false) {\n    // a rejected envelope')}, 'block: a rejected attempt does not block a new one'],`,
  `  [T, ${JSON.stringify("o.status === 'FAILED' && o.reason === 'SUBMISSION_REJECTED');\n  }")}, ${JSON.stringify("o.status === 'FAILED' && o.reason === 'SUBMISSION_REJECTED' && false);\n  }")}, 'state: rejected records never block'],`,
].join('\n');
m = m.replace('const M = [\n', 'const M = [\n' + add + '\n');
m = m.replace("for (const [file, from, to, label, suite = 'fast'] of M) {", "const ONLY = process.env.MUT_ONLY ? new RegExp(process.env.MUT_ONLY) : null;\nfor (const [file, from, to, label, suite = 'fast'] of M) {\n  if (ONLY && !ONLY.test(label)) continue;");
fs.writeFileSync('mutate.cjs', m);
console.log('patched');
