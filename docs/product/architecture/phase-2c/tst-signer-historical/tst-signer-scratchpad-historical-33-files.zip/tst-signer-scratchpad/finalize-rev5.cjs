'use strict';
// Builds docs/product/architecture/phase-2c/tst-signer-revision-5/ from the final working sources: runs the syntax check and every test
// file (counts parsed from the real output), reads the mutation log, writes REVISION-5-REVIEW.md, copies every file as .txt with the same
// relative path, and writes SHA256SUMS.txt. Writes only into the new package directory. Reads only the signer directory.
const fs = require('fs'); const path = require('path'); const crypto = require('crypto');
const { spawnSync } = require('child_process');
const OUT = 'C:/Users/Ebubechi/Documents/codes/scf/tobin-protocol/tobin/docs/product/architecture/phase-2c/tst-signer-revision-5';
const SRC = [
  'refusal.cjs', 'authorization.cjs', 'tst-signer-core.cjs', 'tst-signer.cjs', 'dpapi-key.cjs', 'sdk-loader.cjs', 'state-store.cjs', 'pinned.cjs',
  'make-deployment-config.cjs', 'mutate.cjs', 'dryrun-live.cjs', 'evidence.cjs', 'windows-validation.cjs', 'acl-experiment.cjs', 'auth-evidence.cjs', 'auth-probe.cjs',
  'test/helpers.cjs', 'test/tst-signer.test.cjs', 'test/hardening.test.cjs', 'test/submission.test.cjs', 'test/expiry.test.cjs', 'test/windows.test.cjs',
  'test/authorization.test.cjs', 'test/dpapi-cleanup.test.cjs', 'test/fixtures/real-auth-entries.json',
];
const TESTS = ['test/tst-signer.test.cjs', 'test/hardening.test.cjs', 'test/submission.test.cjs', 'test/expiry.test.cjs', 'test/authorization.test.cjs', 'test/windows.test.cjs', 'test/dpapi-cleanup.test.cjs'];
const sha = (f) => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
for (const f of SRC) if (!fs.existsSync(f)) throw new Error('missing source: ' + f);
if (fs.existsSync(OUT) && fs.readdirSync(OUT).length) throw new Error('package directory already exists and is not empty');

// 1. syntax
for (const f of SRC.filter((x) => x.endsWith('.cjs'))) { const r = spawnSync(process.execPath, ['--check', f], { encoding: 'utf8' }); if (r.status !== 0) throw new Error('syntax error in ' + f + '\n' + r.stderr); }

// 2. tests, file by file, then all together
const count = (out, k) => { const m = new RegExp(`ℹ ${k} (\\d+)`).exec(out); return m ? Number(m[1]) : NaN; };
const rows = []; let total = 0, pass = 0, fail = 0;
for (const t of TESTS) {
  const r = spawnSync(process.execPath, ['--test', t], { encoding: 'utf8' });
  const n = count(r.stdout, 'tests'), p = count(r.stdout, 'pass'), f = count(r.stdout, 'fail');
  rows.push({ t, n, p, f }); total += n; pass += p; fail += f;
}
const all = spawnSync(process.execPath, ['--test', ...TESTS], { encoding: 'utf8' });
const allN = count(all.stdout, 'tests'), allP = count(all.stdout, 'pass'), allF = count(all.stdout, 'fail'), allS = count(all.stdout, 'skipped');
if (allF !== 0 || allN !== total) throw new Error(`test run not green or inconsistent: all=${allN}/${allP}/${allF}, sum=${total}`);
const authN = rows.find((r) => r.t.endsWith('authorization.test.cjs')).n; const dpN = rows.find((r) => r.t.endsWith('dpapi-cleanup.test.cjs')).n;
const testTable = ['| Test file | Tests | Passed | Failed |', '|---|---:|---:|---:|', ...rows.map((r) => `| \`${r.t}\` | ${r.n} | ${r.p} | ${r.f} |`), `| **All seven files together** | **${allN}** | **${allP}** | **${allF}** |`].join('\n');
const testResults = `Command: \`node --test ${TESTS.join(' ')}\` (Node 24.14.0, Windows). Result: **${allN} tests, ${allP} passed, ${allF} failed, ${allS} skipped.**\n\n${testTable}\n\n` +
  `Baseline (revision 4, verified against the actual source before any change): 107 tests, all passing (25 core, 31 hardening, 25 submission, 13 expiry, 13 Windows). Revision 5 adds **${authN + dpN} new tests** (${authN} authorization, ${dpN} BSTR cleanup) for a total of ${allN}; no existing test was removed or weakened (the existing test files are unchanged except two path strings in the CLI-copy lists of \`test/windows.test.cjs\` and the shared mock in \`test/helpers.cjs\`, which now returns the approved authorization entries it used to omit).\n\n` +
  `Authorization tests cover: the correct entry for each operation (object, base64 and bytes input; deterministic, input not modified); real evidence (the specification-derived entries are byte-identical to a live protocol-30 deploy simulation and to the real on-chain mint); wrong, unsupported and edited credential kinds; wrong recipient, deployer, minter; wrong root contract (including an account address in place of a contract); wrong function name (nine variants); wrong argument count, type (including unsupported ScVal types) and value (including 128-bit extremes and sign); wrong constructor parameters, Wasm hash and salt; unsupported function, executable and preimage kinds; unexpected nested invocations at any depth and unexpected branches; missing, additional, duplicate and reordered entries; malformed XDR, trailing data, truncation, random bytes and non-canonical base64 text (newline, whitespace, URL-safe alphabet, missing padding, non-zero trailing bits); unknown XDR discriminants; each comparison layer on its own; refusal of a changed simulation response before anything is assembled, signed or sent (with the key never loaded and nothing recorded); tampered authorization on the assembled transaction.\n\n` +
  `BSTR cleanup tests run the **production** PowerShell function in a real PowerShell with instrumented stand-ins and a dummy SecureString: success (allocate, convert, zero-free, dispose), failure after allocation (still freed and disposed), failure of the allocation (nothing freed, still disposed), failure of the free step (disposal still happens), the real unmanaged calls, a control showing the disposal probe distinguishes alive from disposed, and static shape checks of the production script.`;

// 3. mutation log
const log = fs.readFileSync('mutate-rev5.log', 'utf8').split('\n');
const base = /baseline (\{.*\})/.exec(log.find((l) => l.startsWith('baseline')) || '')?.[1];
const summary = /^mutants (\d+), survived or not applied (\d+)/.exec(log.find((l) => l.startsWith('mutants ')) || '');
if (!base || !summary) throw new Error('mutation log incomplete');
const killed = log.filter((l) => l.startsWith('killed')).length; const surv = log.filter((l) => /^(SURVIVED|NOT APPLIED)/.test(l));
const baseObj = JSON.parse(base); if (baseObj.fail !== 0) throw new Error('mutation baseline not green');
const authM = log.filter((l) => /\b(auth:|core: (assembled|simulated))/.test(l)).length; const dpM = log.filter((l) => /dpapi:/.test(l)).length;
const firstRun = fs.existsSync('mutate-rev5-firstrun.log') ? fs.readFileSync('mutate-rev5-firstrun.log', 'utf8').split('\n') : [];
const fr = /^mutants (\d+), survived or not applied (\d+)/.exec(firstRun.find((l) => l.startsWith('mutants ')) || '');
const notes = fs.existsSync('r5-mutation-notes.md') ? fs.readFileSync('r5-mutation-notes.md', 'utf8') : '';
const mutationResults = `Command: \`node mutate.cjs\`. The harness first runs all seven test files and **aborts unless the baseline is green** (baseline: ${baseObj.pass} passing, ${baseObj.fail} failing). Each mutant weakens exactly one rule in the source and is then run against the offline suites (fast) or the Windows suites (win); a mutant is *killed* when at least one test fails.\n\n` +
  `**Final run: ${summary[1]} mutants attempted, ${killed} killed, ${surv.length} surviving or not applied.**\n\n` +
  (surv.length ? `Surviving or not applied:\n${surv.map((s) => `- ${s.trim()}`).join('\n')}\n\n` : 'No mutant survived and none failed to apply.\n\n') +
  `Of these, ${authM} target the authorization module and its two call sites in the core (entry count, duplicates, credential kinds, canonical encoding, depth, field checks, contract and function kinds, deployer, salt, Wasm hash, function name, argument lists and each value type, nested invocations, both comparison layers, the comparison helper, the expectation for each operation, and each of the two integration points) and ${dpM} target the BSTR cleanup (free removed, free when nothing allocated, disposal removed, disposal skipped on a failing free, non-zeroing free, wrong conversion call, allocation moved outside the protected block, trailing-newline trim, buffer zeroing). The remainder are the revision-3 and revision-4 mutants, re-run against the current source.\n\n` +
  (fr ? `History of this revision: the first complete run (before the survivor fixes) attempted ${fr[1]} mutants with ${fr[2]} surviving or not applied; they were analysed, tests were added or code simplified, and the whole harness was re-run from scratch to produce the final figures above. Details:\n\n` : '') + notes;

// 4. write the package
const review = fs.readFileSync('review-r5.template.md', 'utf8')
  .split('__AUTH_TESTS__').join(String(authN)).split('__DPAPI_TESTS__').join(String(dpN)).split('__NEW_MUTANTS__').join(String(authM + dpM))
  .split('__TEST_RESULTS__').join(testResults).split('__MUTATION_RESULTS__').join(mutationResults);
fs.mkdirSync(OUT, { recursive: true });
const lines = [];
for (const f of SRC) {
  const dest = path.join(OUT, f + '.txt'); fs.mkdirSync(path.dirname(dest), { recursive: true }); fs.copyFileSync(f, dest);
  if (sha(f) !== sha(dest)) throw new Error('copy differs: ' + f);
  lines.push(`${sha(f)}  ${f}`);
}
fs.writeFileSync(path.join(OUT, 'REVISION-5-REVIEW.md'), review);
lines.push(`${sha(path.join(OUT, 'REVISION-5-REVIEW.md'))}  REVISION-5-REVIEW.md`);
fs.writeFileSync(path.join(OUT, 'SHA256SUMS.txt'), ['# SHA-256 of the revision-5 signer package. Each .txt copy has the hash of the original file named here; REVISION-5-REVIEW.md is stored as is.',
  '# Computed 2026-11-04. Verify with Get-FileHash -Algorithm SHA256 <file> (for a .txt copy, compare with the line for the name without the .txt suffix).',
  '# This list is only independent once a copy of it is kept outside the directory that holds the package.', ...lines, ''].join('\n'));
console.log(`package written: ${SRC.length + 2} files; tests ${allN} pass ${allP} fail ${allF}; mutants ${summary[1]} killed ${killed} not-killed ${surv.length}`);
