**First complete run (129 mutants): 124 killed, 4 survived, 1 definition was stale.** Each was analysed:

| Result | Mutant | Cause and action |
|---|---|---|
| survived | non-canonical encoding accepted (the re-encode check) | A **test gap**, not an equivalent mutant. An experiment showed the SDK's decoder tolerates non-canonical base64 text (trailing newline, inner whitespace, URL-safe alphabet, missing padding, non-zero trailing bits), so the re-encode check is a real control. A test with those forms was added |
| survived | contract-call fields not checked | Test gap: only the function level had an extra-field test. A plain-object test for the contract-call node (extra and missing field) was added |
| survived | other deployment preimage kinds accepted | Test gap: only a discriminant edit was tested (which fails in the decoder). A test with a `fromAsset` preimage was added |
| survived | value types not compared (in `firstDifference`) | The guard was **redundant**, and examining it showed that `firstDifference({}, null)` would have thrown a `TypeError`. The function was simplified to one guard that handles null, primitives and mixed shapes; exact-answer tests and three new mutants were added |
| not applied | original authorization-type check | The mutant targeted the old credential loop that this revision removed; it is replaced by "any credential kind accepted", which is killed |

After these fixes the **entire harness was re-run from scratch** on the final source, with the result reported above.

**Not mutation-tested (unreachable):** the two entry-level `requireKeys` calls in `validateAuthorizationEntries` (on the decoded entry and on its credentials). They run on objects produced by the strict XDR decoder, whose shape is fixed, so a mutant removing them would be equivalent; they are kept as defence in depth against a future SDK that adds a field.
