'use strict';
const fs = require('fs');
let t = fs.readFileSync('test/expiry.test.cjs', 'utf8');
const a = t.indexOf("test('windowClosedByNetwork: the exact boundaries'");
const b = t.indexOf("test('windowClosedByNetwork: malformed network-time evidence");
if (a < 0 || b < 0) throw new Error('anchors');
const boundaries = `test('windowClosedByNetwork: the exact boundaries', () => {
  const now = realNow(); const maxTime = now - 1000; const sub = now - 2000;
  const r = { submittedAt: new Date(sub * 1000).toISOString(), maxTime };
  const f = (g, rr = r) => core.windowClosedByNetwork(rr, g, now);
  const base = { status: 'NOT_FOUND', latestLedgerCloseTime: String(maxTime + 31), oldestLedgerCloseTime: String(sub - 61) };
  assert.equal(f(base).closed, true);
  assert.equal(f({ ...base, latestLedgerCloseTime: String(maxTime + 30) }).closed, false);    // not strictly past maxTime + 30
  assert.equal(f({ ...base, latestLedgerCloseTime: String(maxTime) }).closed, false);         // exactly at the end of the window
  assert.equal(f({ ...base, latestLedgerCloseTime: String(maxTime - 900) }).closed, false);   // stale
  assert.equal(f({ ...base, oldestLedgerCloseTime: String(sub - 60) }).closed, false);        // history starts too close to the submission
  assert.equal(f({ ...base, oldestLedgerCloseTime: String(sub) }).closed, false);
  assert.equal(f({ ...base, latestLedgerCloseTime: String(now + 301) }).closed, false);       // implausibly in the future
  assert.equal(f({ ...base, latestLedgerCloseTime: now, oldestLedgerCloseTime: sub - 61 }).closed, true); // numbers are accepted too
  for (const g of [undefined, null, 'NOT_FOUND', {}, { status: 'SUCCESS', latestLedgerCloseTime: String(now), oldestLedgerCloseTime: '1' }, { status: 'FAILED' }]) assert.equal(f(g).closed, false);
  assert.equal(f(base, { ...r, submittedAt: 'garbage' }).closed, false);
  assert.equal(f(base, { ...r, submittedAt: undefined }).closed, false);
});

`;
t = t.slice(0, a) + boundaries + t.slice(b);
// malformed-evidence pure test: use real-scale numbers too
t = t.replace("const r = { submittedAt: new Date((realNow() - 2000) * 1000).toISOString(), maxTime: 1_000_000 };\n  const ok = { status: 'NOT_FOUND', latestLedgerCloseTime: '1000100', oldestLedgerCloseTime: '5' };\n  assert.equal(core.windowClosedByNetwork(r, ok, 1_000_900).closed, true);",
  "const now = realNow(); const r = { submittedAt: new Date((now - 2000) * 1000).toISOString(), maxTime: now - 1000 };\n  const ok = { status: 'NOT_FOUND', latestLedgerCloseTime: String(now - 500), oldestLedgerCloseTime: '5' };\n  assert.equal(core.windowClosedByNetwork(r, ok, now).closed, true);");
t = t.replace(/windowClosedByNetwork\(r, \{ \.\.\.ok, latestLedgerCloseTime: bad \}, 1_000_900\)/, 'windowClosedByNetwork(r, { ...ok, latestLedgerCloseTime: bad }, now)')
     .replace(/windowClosedByNetwork\(r, \{ \.\.\.ok, oldestLedgerCloseTime: bad \}, 1_000_900\)/, 'windowClosedByNetwork(r, { ...ok, oldestLedgerCloseTime: bad }, now)')
     .replace("windowClosedByNetwork(r, { ...ok, latestLedgerCloseTime: '4', oldestLedgerCloseTime: '5' }, 1_000_900)", "windowClosedByNetwork(r, { ...ok, latestLedgerCloseTime: '4', oldestLedgerCloseTime: '5' }, now)");
// stale-information test: keep latest >= oldest so the coverage rule itself is what is exercised
t = t.replace("await stays(m, seq(nf({ oldestLedgerCloseTime: String(realNow() - 2000) })), /does not clearly cover the submission/);\n  await stays(m, seq(nf({ oldestLedgerCloseTime: String(realNow() - 100) })), /does not clearly cover/);",
  "await stays(m, seq(nf({ latestLedgerCloseTime: String(realNow()), oldestLedgerCloseTime: String(realNow() - 2000) })), /does not clearly cover the submission/);\n  await stays(m, seq(nf({ latestLedgerCloseTime: String(realNow()), oldestLedgerCloseTime: String(realNow() - 100) })), /does not clearly cover/);");
fs.writeFileSync('test/expiry.test.cjs', t);
console.log('patched');
