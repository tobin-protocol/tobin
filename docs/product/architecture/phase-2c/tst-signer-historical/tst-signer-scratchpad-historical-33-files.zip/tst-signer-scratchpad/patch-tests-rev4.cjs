'use strict';
const fs = require('fs');
const edit = (file, pairs) => {
  let t = fs.readFileSync(file, 'utf8');
  for (const [a, b] of pairs) { if (!t.includes(a)) throw new Error(`${file} missing: ${a.slice(0, 80)}`); t = t.replace(a, () => b); }
  fs.writeFileSync(file, t);
};

// hardening: the "long past its window" case must now carry network-time evidence
edit('test/hardening.test.cjs', [
  ["  m = makeDeps('mint-C', { rpcOver: { getTx: async (h) => (h === hash ? { status: 'NOT_FOUND' } : { status: 'SUCCESS', ledger: 9, returnValue: x.ScVal.scvVoid() }) } }); seed(m, realNow() - 1000);",
   "  const evidence = { status: 'NOT_FOUND', latestLedger: 9, oldestLedger: 1, latestLedgerCloseTime: String(realNow() + 5), oldestLedgerCloseTime: String(realNow() - 400000) };\n  m = makeDeps('mint-C', { rpcOver: { getTx: async (h) => (h === hash ? evidence : { status: 'SUCCESS', ledger: 9, returnValue: x.ScVal.scvVoid() }) } }); seed(m, realNow() - 1000);"],
]);

// submission: expiry and the rejected-attempt block now need the NETWORK to show the window closed
edit('test/submission.test.cjs', [
  ["const NF = 'NOT_FOUND';",
   "const NF = 'NOT_FOUND';\n// a NOT_FOUND answer that carries network-time evidence (latest ledger closed after the window; history reaches back days)\nconst nfNet = (o = {}) => ({ status: 'NOT_FOUND', latestLedger: 5000, oldestLedger: 1, latestLedgerCloseTime: String(realNow() + 5), oldestLedgerCloseTime: String(realNow() - 5 * 86400), ...o });"],
  ["  const after = again(m, { getTx: seq(NF, { status: 'SUCCESS', ledger: 66, returnValue: x.ScVal.scvVoid() }) });",
   "  const after = again(m, { getTx: seq(nfNet(), { status: 'SUCCESS', ledger: 66, returnValue: x.ScVal.scvVoid() }) });"],
  ["age(m); const after = again(m, { getTx: seq(NF, 'SUCCESS') });", "age(m); const after = again(m, { getTx: seq(nfNet(), 'SUCCESS') });"],
  ["  const early = again(m); await rej(run(early), /previous mint-C submission was rejected/); assert.equal(early.rpc.calls.sent, 0); assert.equal(early.counters.keyLoads, 0);\n  age(m); const later = again(m); await run(later);\n  assert.equal(ops(m)[0].status, 'FAILED'); assert.equal(ops(m)[1].status, 'SUCCEEDED'); assert.equal(later.rpc.calls.sent, 1);",
   "  const early = again(m, { getTx: seq(NF) }); await rej(run(early), /rejected and its window cannot yet be proven closed/); assert.equal(early.rpc.calls.sent, 0); assert.equal(early.counters.keyLoads, 0);\n  age(m); const later = again(m, { getTx: seq(nfNet(), 'SUCCESS') }); await run(later);\n  assert.equal(ops(m)[0].status, 'FAILED'); assert.equal(ops(m)[0].reason, 'SUBMISSION_REJECTED_WINDOW_CLOSED'); assert.equal(ops(m)[1].status, 'SUCCEEDED'); assert.equal(later.rpc.calls.sent, 1);"],
]);
console.log('tests patched');
