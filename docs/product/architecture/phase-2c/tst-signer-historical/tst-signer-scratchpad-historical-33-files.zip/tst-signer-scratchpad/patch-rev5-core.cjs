'use strict';
// Revision 5 edit of the core: the refusal type moves to refusal.cjs; authorization entries are validated by authorization.cjs.
const fs = require('fs');
let t = fs.readFileSync('tst-signer-core.cjs', 'utf8');
const rep = (a, b) => { if (!t.includes(a)) throw new Error('missing: ' + a.slice(0, 80)); t = t.replace(a, () => b); };

// 1. shared refusal type and redaction
const i = t.indexOf('class Refusal extends Error {}'); const j = t.indexOf('// ---------- configuration and contract-ID prediction');
if (i < 0 || j < 0) throw new Error('anchors');
t = t.slice(0, i) + "const { Refusal, redact, refuse } = require('./refusal.cjs');\nconst { validateAuthorizationEntries } = require('./authorization.cjs');\n\n" + t.slice(j);

// 2. the assembled transaction's authorization is validated against the specification (not only the credential kind)
rep("  const auth = op.auth || [];\n  if (!assembled && auth.length !== 0) refuse('unexpected authorization entries before simulation');\n  for (const a of auth) if (credentialType(a) !== 'sorobanCredentialsSourceAccount') refuse('only source-account authorization is allowed');",
    "  const auth = op.auth || [];\n  if (!assembled && auth.length !== 0) refuse('unexpected authorization entries before simulation');\n  if (assembled) validateAuthorizationEntries(S, cfg, opName, auth);   // exact count, credential kind, invocation tree, arguments, nesting");

// 3. the simulation's own authorization entries are validated before the transaction is assembled from them
rep("  const info = verifyFootprint(S, cfg, opName, sim);",
    "  const info = verifyFootprint(S, cfg, opName, sim);\n  validateAuthorizationEntries(S, cfg, opName, sim.result.auth);   // never trust the entries the simulation recorded");

// 4. the unused helper goes away
const a = t.indexOf('function credentialType(entry) {');
if (a >= 0) { const b = t.indexOf('\n}\n', a); t = t.slice(0, a) + t.slice(b + 3); }
fs.writeFileSync('tst-signer-core.cjs', t);
console.log('core patched');
