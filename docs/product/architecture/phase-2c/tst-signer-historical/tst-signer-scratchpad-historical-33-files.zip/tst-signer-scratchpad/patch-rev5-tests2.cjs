const fs = require('fs');
let t = fs.readFileSync('test/authorization.test.cjs', 'utf8');
const i = t.indexOf("test('a malicious simulation is refused before assembly");
if (i < 0) throw new Error('anchor');
t = t.slice(0, i) + `test('a malicious simulation is refused before assembly: no transaction is ever assembled from entries the specification does not approve', async () => {
  // the SDK namespace is frozen, so the spy is injected through the dependency object the core uses
  let assembled = 0;
  const spied = () => Object.create(S, { rpc: { value: { ...S.rpc, assembleTransaction: (...a) => { assembled++; return S.rpc.assembleTransaction(...a); } } } });
  for (const op of OPS) {
    const m = makeDeps(op, { rpcOver: { auth: evil['nested invocation'](op) } }); m.deps.S = spied();
    await rejects(core.preview(m.deps, cfg, op), /authorization/);
  }
  assert.equal(assembled, 0, 'assembleTransaction must not run for a rejected simulation');
  const ok = makeDeps('mint-C'); ok.deps.S = spied();
  await core.preview(ok.deps, cfg, 'mint-C');
  assert.equal(assembled, 1, 'the spy works: an approved simulation is assembled exactly once');
});
`;
fs.writeFileSync('test/authorization.test.cjs', t);
console.log('ok');
