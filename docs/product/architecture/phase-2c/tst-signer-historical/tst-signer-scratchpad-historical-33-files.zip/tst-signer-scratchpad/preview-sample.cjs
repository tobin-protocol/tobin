// Prints a REDACTED sample preview using a throwaway fake F and mocked RPC (no network, no real key).
const test = null;
const { loadSdk } = require('./sdk-loader.cjs'); const S = loadSdk(); const x = S.xdr; const crypto = require('crypto');
const core = require('./tst-signer-core.cjs');
const F = S.Keypair.random().publicKey(); const cfg = core.makeConfig(S, { adminAddress: F, saltHex: crypto.randomBytes(32).toString('hex') });
const rt = (b) => new S.SorobanDataBuilder(b.build().toXDR('base64'));
const fp = () => rt(new S.SorobanDataBuilder().setFootprint([x.LedgerKey.contractCode(new x.LedgerKeyContractCode({ hash: Buffer.from(cfg.wasmHash, 'hex') }))], [x.LedgerKey.contractData(new x.LedgerKeyContractData({ contract: new S.Address(cfg.tokenId).toScAddress(), key: x.ScVal.scvLedgerKeyContractInstance(), durability: x.ContractDataDurability.persistent }))]).setResources(2000000, 5000, 2000).setResourceFee(55971n));
(async () => {
  for (const op of ['deploy', 'mint-C']) {
    const rpc = { getNetwork: async () => ({ passphrase: cfg.passphrase }), getAccount: async (a) => new S.Account(a, '100'),
      simulateTransaction: async () => ({ _parsed: true, id: '1', latestLedger: 1, minResourceFee: '55971', restorePreamble: {}, result: { auth: [], retval: op === 'deploy' ? new S.Address(cfg.tokenId).toScVal() : x.ScVal.scvVoid() }, transactionData: fp() }) };
    const reader = { instanceExists: async () => op !== 'deploy', call: async (id, fn, a = []) => ({ name: cfg.name, symbol: cfg.symbol, decimals: 7, minter: F, cap: 30000n, total_supply: 0n, balance: 0n }[fn]) };
    await core.preview({ S, rpc, reader, log: (s) => console.log(core.redact(s)) }, cfg, op); console.log('');
  }
})();
