'use strict';
const fs = require('fs');
let t = fs.readFileSync('authorization.cjs', 'utf8');
const rep = (a, b) => { if (!t.includes(a)) throw new Error('missing: ' + a.slice(0, 80)); t = t.replace(a, () => b); };

rep(`    requireKeys(entry.credentials, ['type'], \`entry \${i} credentials\`);
    const actual = describeInvocation(S, entry.rootInvocation);
    const want = describeInvocation(S, expected[i].rootInvocation);
    const diff = firstDifference(actual, want);
    if (diff) fail(\`entry \${i} differs from the approved invocation at \${diff}\`);
    if (b64 !== expected[i].toXDR('base64')) fail(\`entry \${i} differs from the approved entry in its canonical bytes\`);
    out.push(actual);`,
`    requireKeys(entry.credentials, ['type'], \`entry \${i} credentials\`);
    out.push(structuralCompare(S, entry, expected[i], i));   // layers 1 and 2: explicit checks and canonical description
    bytesCompare(b64, expected[i], i);                       // layer 3: canonical XDR bytes`);

rep(`/**
 * Validates \`entries\``,
`/** Layers 1 and 2: describe both invocation trees (explicit, recursive, fail-closed) and compare them field by field. */
function structuralCompare(S, actualEntry, expectedEntry, i = 0) {
  const actual = describeInvocation(S, actualEntry.rootInvocation);
  const want = describeInvocation(S, expectedEntry.rootInvocation);
  const diff = firstDifference(actual, want);
  if (diff) fail(\`entry \${i} differs from the approved invocation at \${diff}\`);
  return actual;
}

/** Layer 3: the canonical XDR of the entry must equal the canonical XDR of the expected entry. */
function bytesCompare(actualB64, expectedEntry, i = 0) {
  if (actualB64 !== expectedEntry.toXDR('base64')) fail(\`entry \${i} differs from the approved entry in its canonical bytes\`);
}

/**
 * Validates \`entries\``);
rep("module.exports = { buildExpectedAuthEntry, expectedAuthorizationEntries, decodeAuthorizationEntry, describeInvocation, validateAuthorizationEntries, firstDifference, MAX_DEPTH };",
    "module.exports = { buildExpectedAuthEntry, expectedAuthorizationEntries, decodeAuthorizationEntry, describeInvocation, describeScVal, structuralCompare, bytesCompare, validateAuthorizationEntries, firstDifference, MAX_DEPTH };");
fs.writeFileSync('authorization.cjs', t);
console.log('authorization layers split');
