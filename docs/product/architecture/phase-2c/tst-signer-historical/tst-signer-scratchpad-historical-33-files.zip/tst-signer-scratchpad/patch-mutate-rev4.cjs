'use strict';
const fs = require('fs');
let t = fs.readFileSync('mutate.cjs', 'utf8');
const i = t.indexOf('const orig = {');
if (i < 0) throw new Error('anchor');
// ---- new tail: three file sets, DPAPI module tracked, per-mutant suite selection ----
const tail = `const D = 'dpapi-key.cjs';
const orig = { [C]: fs.readFileSync(C, 'utf8'), [T]: fs.readFileSync(T, 'utf8'), [D]: fs.readFileSync(D, 'utf8') };
// FAST: the offline suites (a few seconds). WIN: real-Windows validation (ACL, DPAPI with dummy data, NTFS, CLI; tens of seconds).
const FAST = ['test/tst-signer.test.cjs', 'test/hardening.test.cjs', 'test/submission.test.cjs', 'test/expiry.test.cjs'];
const WIN = ['test/windows.test.cjs'];
const run = (files) => { const r = spawnSync(process.execPath, ['--test', ...files], { encoding: 'utf8' }); const f = /ℹ fail (\\d+)/.exec(r.stdout); const p = /ℹ pass (\\d+)/.exec(r.stdout); return { fail: f ? +f[1] : -1, pass: p ? +p[1] : -1 }; };
let survived = 0;
const base = run([...FAST, ...WIN]); console.log('baseline', JSON.stringify(base)); if (base.fail !== 0 || base.pass < 100) { console.log('BASELINE NOT GREEN; aborting'); process.exit(1); }
for (const [file, from, to, label, suite = 'fast'] of M) {
  const src = orig[file];
  if (!src.includes(from)) { console.log('NOT APPLIED  ', label); survived++; continue; }
  fs.writeFileSync(file, src.replace(from, () => to));
  const r = run(suite === 'win' ? WIN : FAST); fs.writeFileSync(file, src);
  const killed = r.fail > 0 || r.fail === -1;
  if (!killed) survived++;
  console.log(killed ? 'killed       ' : 'SURVIVED     ', \`(\${r.fail} failing, suite \${suite})\`, label);
}
for (const f of [C, T, D]) fs.writeFileSync(f, orig[f]);
console.log(\`mutants \${M.length}, survived or not applied \${survived}\`);
`;
t = t.slice(0, i) + tail;
// ---- new mutants ----
const C = (a, b, l, s) => `  [C, ${JSON.stringify(a)}, ${JSON.stringify(b)}, ${JSON.stringify(l)}${s ? `, '${s}'` : ''}],`;
const T = (a, b, l, s) => `  [T, ${JSON.stringify(a)}, ${JSON.stringify(b)}, ${JSON.stringify(l)}${s ? `, '${s}'` : ''}],`;
const D = (a, b, l, s) => `  [${JSON.stringify('dpapi-key.cjs')}, ${JSON.stringify(a)}, ${JSON.stringify(b)}, ${JSON.stringify(l)}${s ? `, '${s}'` : ''}],`;
const add = [
  // expiry from network time
  C("if (!(latest > Number(rec.maxTime) + NETWORK_TIME_MARGIN_SECONDS)) return", "if (false) return", 'expiry: ledger close time past the window not required'),
  C("if (oldest > submitted - HISTORY_COVERAGE_MARGIN_SECONDS) return", "if (false) return", 'expiry: history coverage not required'),
  C("if (!Number.isFinite(latest) || !Number.isFinite(oldest)) return", "if (false) return", 'expiry: malformed network time accepted'),
  C("if (latest > nowSeconds + FUTURE_SANITY_SECONDS) return", "if (false) return", 'expiry: future ledger time accepted'),
  C("if (latest < oldest) return", "if (false) return", 'expiry: inconsistent evidence accepted'),
  C("g.status !== 'NOT_FOUND') return { closed: false, why: 'the lookup did not return NOT_FOUND' }", "false) return { closed: false, why: 'x' }", 'expiry: any status can close the window'),
  C("const v = windowClosedByNetwork(rec, g, now);\n      if (v.closed)", "const v = { closed: now > rec.maxTime + 120, why: 'local clock' };\n      if (v.closed)", 'expiry: local clock decides (the old rule)'),
  C("if (!v.closed) refuse(`a previous ${opName} submission was rejected and its window", "if (false) refuse(`a previous ${opName} submission was rejected and its window", 'block: lifted without network evidence'),
  C("if (g && (g.status === 'SUCCESS' || g.status === 'FAILED')) refuse(`the chain shows the rejected", "if (false) refuse(`the chain shows the rejected", 'block: rejected-but-included transaction ignored'),
  C("refuse(`cannot reach the RPC to verify that the rejected ${opName} envelope has expired; no new attempt was made`)", "(g = { status: 'NOT_FOUND', latestLedgerCloseTime: '9999999999', oldestLedgerCloseTime: '1' })", 'block: RPC failure treated as expiry'),
  C("store.resolveRejected(cfg, opName, blocker.txHash, (deps.now || nowDefault)());", "", 'block: the lift is not recorded'),
  // state store
  T("if (created) { try { fs.unlinkSync(tmp); } catch { /* ignore */ } }", "if (true) { try { fs.unlinkSync(tmp); } catch { /* ignore */ } }", 'state: cleanup may delete a file this call did not create', 'win'),
  T("      restrict(tmp);\n", "", 'state: permissions never applied', 'win'),
  T("      restrict(tmp);\n", "      try { restrict(tmp); } catch { /* ignored */ }\n", 'state: permission failure ignored', 'win'),
  T("if (typeof restrict.verify === 'function') {", "if (false) {", 'state: final file ACL not verified', 'win'),
  T("if (a.protected !== true) problems.push(", "if (false) problems.push(", 'acl: inheritance not required to be blocked', 'win'),
  T("if (a.owner !== a.me) problems.push(", "if (false) problems.push(", 'acl: owner not checked', 'win'),
  T("if (a.rules.length !== 1) problems.push(", "if (false) problems.push(", 'acl: extra rules tolerated', 'win'),
  T("if (r.sid !== a.me) problems.push(", "if (false) problems.push(", 'acl: other principals tolerated', 'win'),
  T("if (r.inherited) problems.push(", "if (false) problems.push(", 'acl: inherited rule tolerated', 'win'),
  T("if (!/FullControl/.test(String(r.rights))) problems.push(", "if (false) problems.push(", 'acl: user rights not checked', 'win'),
  T("return verifyOwnerOnly(file, { platform, exec, fs });   // the outcome is judged from the real ACL, not from the exit code", "return { applied: true, how: 'unchecked' };   //", 'acl: exit code trusted, result not inspected', 'win'),
  T("catch { throw new StateError('icacls failed; owner-only access could not be applied'); }", "catch { /* ignored */ }", 'acl: icacls failure ignored', 'win'),
  T("if (!v.ok) throw new StateError(`owner-only access is not in place: ${v.problems.join('; ')}`);", "if (false) throw new StateError(`owner-only access is not in place: ${v.problems.join('; ')}`);", 'acl: verification verdict ignored', 'win'),
  // DPAPI
  D("'$s = (Get-Content -Raw $f).Trim() | ConvertTo-SecureString; ' +", "'$s = Get-Content -Raw $f | ConvertTo-SecureString; ' +", 'dpapi: trailing newline not trimmed (the defect found on Windows)', 'win'),
  D("if (Buffer.isBuffer(buf)) buf.fill(0);", "", 'dpapi: decrypted buffer not zero-filled', 'win'),
].join('\n');
t = t.replace('const M = [\n', 'const M = [\n' + add + '\n');
fs.writeFileSync('mutate.cjs', t);
console.log('mutate.cjs patched');
