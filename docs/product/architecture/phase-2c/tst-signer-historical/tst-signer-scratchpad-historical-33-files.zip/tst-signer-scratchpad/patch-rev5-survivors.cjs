'use strict';
const fs = require('fs');
const edit = (file, pairs) => {
  let t = fs.readFileSync(file, 'utf8');
  for (const [a, b] of pairs) { if (!t.includes(a)) throw new Error(`${file} missing: ${a.slice(0, 80)}`); t = t.replace(a, () => b); }
  fs.writeFileSync(file, t);
};

// 1. firstDifference: one guard covers null, primitives and mixed shapes (the former separate type guard was redundant and left a null crash)
edit('authorization.cjs', [[
`function firstDifference(a, b, path = '') {
  if (typeof a !== typeof b) return path || 'value';
  if (a === null || typeof a !== 'object') return a === b ? null : (path || 'value');
  if (Array.isArray(a) !== Array.isArray(b)) return path || 'value';`,
`function firstDifference(a, b, path = '') {
  if (a === null || b === null || typeof a !== 'object' || typeof b !== 'object') return a === b ? null : (path || 'value');
  if (Array.isArray(a) !== Array.isArray(b)) return path || 'value';`]]);

// 2. tests for what the survivors showed was untested
let t = fs.readFileSync('test/authorization.test.cjs', 'utf8');
t += `
test('non-canonical base64 text is rejected even though the decoder tolerates it (newline, whitespace, URL-safe alphabet, missing padding, non-zero trailing bits)', () => {
  const alpha = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  let variants = 0;
  for (const op of OPS) {
    const g = b64(goodAuth(op)[0]); const raw = Buffer.from(g, 'base64');
    const forms = [g + '\\n', g + ' ', ' ' + g, g.slice(0, 16) + '\\n' + g.slice(16), g.slice(0, 20) + ' ' + g.slice(20)];
    if (/[+/]/.test(g)) forms.push(g.replace(/\\+/g, '-').replace(/\\//g, '_'));
    if (/=$/.test(g)) forms.push(g.replace(/=+$/, ''));
    if (raw.length % 3 !== 0) { const core64 = g.replace(/=+$/, ''); const c = core64[core64.length - 1]; forms.push(core64.slice(0, -1) + alpha[alpha.indexOf(c) ^ 1] + g.slice(core64.length)); }
    for (const f of forms) { refused(() => val(op, [f]), /does not re-encode|cannot be decoded/); variants++; }
    val(op, [g]);                                                                                    // the canonical text itself is accepted
  }
  assert.ok(variants >= 15, 'enough non-canonical variants were exercised: ' + variants);
});

test('a contract-call node with an extra or missing field, and a deployment preimage of another kind, are rejected', () => {
  const fn = goodAuth('mint-C')[0].rootInvocation.function;
  const call = fn.contractFn;
  assert.throws(() => A.describeInvocation(S, { function: { type: fn.type, contractFn: { ...call, extra: 1 } }, subInvocations: [] }), /contract call has unexpected or missing fields/);
  assert.throws(() => A.describeInvocation(S, { function: { type: fn.type, contractFn: { contractAddress: call.contractAddress, functionName: call.functionName } }, subInvocations: [] }), /contract call has unexpected or missing fields/);
  const fromAsset = x.SorobanAuthorizedFunction.sorobanAuthorizedFunctionTypeCreateContractV2HostFn(new x.CreateContractArgsV2({
    contractIdPreimage: x.ContractIdPreimage.contractIdPreimageFromAsset(S.Asset.native().toXDRObject()),
    executable: x.ContractExecutable.contractExecutableWasm(Buffer.from(cfg.wasmHash, 'hex')), constructorArgs: [] }));
  refused(() => val('deploy', [authEntry({ fn: fromAsset })]), /preimage kind is not supported/);
});

test('firstDifference gives exact answers for nulls, primitives, mixed shapes and nested paths (and never throws)', () => {
  assert.equal(A.firstDifference({ a: 1 }, { a: '1' }), 'a');
  assert.equal(A.firstDifference({}, null), 'value'); assert.equal(A.firstDifference(null, {}), 'value'); assert.equal(A.firstDifference(null, null), null);
  assert.equal(A.firstDifference({ a: 1 }, 5), 'value'); assert.equal(A.firstDifference(5, { a: 1 }), 'value'); assert.equal(A.firstDifference(5, 5), null);
  assert.equal(A.firstDifference([], {}), 'value'); assert.equal(A.firstDifference({}, []), 'value'); assert.equal(A.firstDifference([1, [2]], [1, [3]]), '[1][0]');
  assert.equal(A.firstDifference({ a: { b: [1, { c: 2 }] } }, { a: { b: [1, { c: 3 }] } }), 'a.b[1].c');
  assert.equal(A.firstDifference({ a: undefined }, { a: undefined }), null); assert.equal(A.firstDifference('x', 'x'), null);
});
`;
fs.writeFileSync('test/authorization.test.cjs', t);

// 3. harness: drop two stale/obsolete definitions, add mutants for the simplified function
let m = fs.readFileSync('mutate.cjs', 'utf8');
const dropLine = (needle) => { const i = m.indexOf(needle); if (i < 0) throw new Error('missing ' + needle); const s = m.lastIndexOf('\n', i) + 1; const e = m.indexOf('\n', i) + 1; m = m.slice(0, s) + m.slice(e); };
dropLine('original: authorization-type check');      // the credential loop it targeted no longer exists (replaced by 'auth: any credential kind accepted')
dropLine('auth: value types not compared');          // the guard it targeted was redundant and has been simplified away
const Z = (a, b, l) => `  ["authorization.cjs", ${JSON.stringify(a)}, ${JSON.stringify(b)}, ${JSON.stringify(l)}],`;
const add = [
  Z("if (a === null || b === null || typeof a !== 'object' || typeof b !== 'object') return", "if (a === null || typeof a !== 'object') return", 'auth: comparison crashes or misjudges nulls and mixed types'),
  Z("|| typeof b !== 'object') return a === b ? null : (path || 'value');", ") return a === b ? null : (path || 'value');", 'auth: second operand type not checked'),
  Z("if (Array.isArray(a) !== Array.isArray(b)) return path || 'value';", "", 'auth: list versus object not distinguished'),
].join('\n');
m = m.replace('const M = [\n', 'const M = [\n' + add + '\n');
fs.writeFileSync('mutate.cjs', m);
console.log('survivor fixes applied');
