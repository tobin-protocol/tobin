'use strict';
const fs = require('fs');
let t = fs.readFileSync('test/helpers.cjs', 'utf8');
const rep = (a, b) => { if (!t.includes(a)) throw new Error('missing: ' + a.slice(0, 80)); t = t.replace(a, () => b); };

// independent builders of authorization entries (raw XDR constructors, written separately from the signer's own derivation)
rep("// ---------- mocked RPC ----------",
`// ---------- authorization entries: the shapes Soroban records (see the evidence in the review), built independently ----------
const sc = (a) => new S.Address(a).toScAddress();
const authEntry = ({ credentials, fn, subs = [] } = {}) => new x.SorobanAuthorizationEntry({
  credentials: credentials ?? x.SorobanCredentials.sorobanCredentialsSourceAccount(),
  rootInvocation: new x.SorobanAuthorizedInvocation({ function: fn, subInvocations: subs }),
});
const mintFn = ({ contract = cfg.tokenId, name = 'mint', args } = {}) => x.SorobanAuthorizedFunction.sorobanAuthorizedFunctionTypeContractFn(new x.InvokeContractArgs({ contractAddress: sc(contract), functionName: name, args }));
const argAddr = (a) => new S.Address(a).toScVal();
const argI128 = (v) => S.nativeToScVal(v, { type: 'i128' });
const subOf = (fn, subs = []) => new x.SorobanAuthorizedInvocation({ function: fn, subInvocations: subs });
const deployFn = ({ deployer = cfg.F, salt = cfg.salt, wasm = cfg.wasmHash, ctor } = {}) => x.SorobanAuthorizedFunction.sorobanAuthorizedFunctionTypeCreateContractV2HostFn(new x.CreateContractArgsV2({
  contractIdPreimage: x.ContractIdPreimage.contractIdPreimageFromAddress(new x.ContractIdPreimageFromAddress({ address: sc(deployer), salt })),
  executable: x.ContractExecutable.contractExecutableWasm(Buffer.from(wasm, 'hex')),
  constructorArgs: ctor ?? [argAddr(cfg.F), argI128(30000n), S.nativeToScVal(7, { type: 'u32' }), S.nativeToScVal('Tobin Settlement Test Token', { type: 'string' }), S.nativeToScVal('TST', { type: 'string' })],
}));
const goodAuthFn = (opName) => (opName === 'deploy' ? deployFn() : mintFn({ args: [argAddr(opName === 'mint-C' ? cfg.C : cfg.D), argI128(opName === 'mint-C' ? 20000n : 10000n)] }));
const goodAuth = (opName) => [authEntry({ fn: goodAuthFn(opName) })];

// ---------- mocked RPC ----------`);
rep("result: { auth: [], retval:", "result: { auth: over.auth ?? goodAuth(opName), retval:");
rep("module.exports = { S, x, core,", "module.exports = { authEntry, mintFn, deployFn, subOf, argAddr, argI128, sc, goodAuth, goodAuthFn, S, x, core,");
fs.writeFileSync('test/helpers.cjs', t);
console.log('helpers patched');
