'use strict';
// One-off patch script for revision 4 (applied once; kept only so the edit is reviewable).
const fs = require('fs');
const edit = (file, pairs) => {
  let t = fs.readFileSync(file, 'utf8');
  for (const [a, b] of pairs) { if (!t.includes(a)) throw new Error(`${file} missing: ${a.slice(0, 70)}`); t = t.replace(a, () => b); }
  fs.writeFileSync(file, t);
};

// ---------------- core ----------------
edit('tst-signer-core.cjs', [
  ['/** Settles any PENDING record left by an interrupted or ambiguous run against the chain before anything new is attempted. */',
`// ---------- is the validity window of a transaction provably closed? ----------
// A transaction is valid only in ledgers whose close time is <= its maximum time. A NOT_FOUND answer proves expiry only when the
// SAME answer shows (1) the RPC has ingested a ledger that closed after the window (latestLedgerCloseTime > maxTime + margin), so
// no ledger that could still have included it is missing, and (2) the RPC's history reaches back before the submission
// (oldestLedgerCloseTime <= submittedAt - margin), so an earlier inclusion would still be visible. The local clock is NOT used to
// decide expiry; it is only a sanity bound against an implausible future ledger time. Anything missing, malformed or stale
// leaves the record PENDING: the signer never invents certainty.
const NETWORK_TIME_MARGIN_SECONDS = 30;
const HISTORY_COVERAGE_MARGIN_SECONDS = 60;
const FUTURE_SANITY_SECONDS = 300;
function windowClosedByNetwork(rec, g, nowSeconds) {
  if (!g || typeof g !== 'object' || g.status !== 'NOT_FOUND') return { closed: false, why: 'the lookup did not return NOT_FOUND' };
  const num = (v) => ((typeof v === 'number' && Number.isInteger(v) && v >= 0) ? v : (typeof v === 'string' && /^\\d+$/.test(v) ? Number(v) : NaN));
  const latest = num(g.latestLedgerCloseTime); const oldest = num(g.oldestLedgerCloseTime);
  if (!Number.isFinite(latest) || !Number.isFinite(oldest)) return { closed: false, why: 'network time evidence is missing or malformed' };
  if (latest < oldest) return { closed: false, why: 'network time evidence is inconsistent (latest earlier than oldest)' };
  if (latest > nowSeconds + FUTURE_SANITY_SECONDS) return { closed: false, why: 'reported ledger time is implausibly far in the future' };
  const submitted = Date.parse(rec.submittedAt) / 1000;
  if (!Number.isFinite(submitted)) return { closed: false, why: 'the record has no usable submission time' };
  if (oldest > submitted - HISTORY_COVERAGE_MARGIN_SECONDS) return { closed: false, why: 'the RPC history does not clearly cover the submission window' };
  if (!(latest > Number(rec.maxTime) + NETWORK_TIME_MARGIN_SECONDS)) return { closed: false, why: \`the latest ledger close time (\${latest}) has not passed the end of the validity window (\${rec.maxTime}); the RPC may be lagging or the window is still open\` };
  return { closed: true, why: \`ledger close time \${latest} is past the validity window end \${rec.maxTime} and the RPC history covers the submission\` };
}

/** Settles any PENDING record left by an interrupted or ambiguous run against the chain before anything new is attempted. */`],
  ["    else if (g.status === 'NOT_FOUND' && now > rec.maxTime + 120) store.markResult(cfg, rec.operation, 'EXPIRED', { now, reason: 'WINDOW_PASSED_NOT_FOUND' });\n    else refuse(`the outcome of a previous ${rec.operation} transaction is not known yet (status ${g.status}); wait and re-run`);",
`    else if (g.status === 'NOT_FOUND') {
      const v = windowClosedByNetwork(rec, g, now);
      if (v.closed) store.markResult(cfg, rec.operation, 'EXPIRED', { now, reason: 'WINDOW_PASSED_NOT_FOUND' });
      else refuse(\`the outcome of a previous \${rec.operation} transaction is not known yet (NOT_FOUND; \${v.why}); the record stays PENDING; wait and re-run\`);
    } else refuse(\`the outcome of a previous \${rec.operation} transaction is not known yet (status \${g.status}); wait and re-run\`);`],
  ["  const blocker = store.blocking(st, opName, (deps.now || nowDefault)());\n  if (blocker) refuse(`a previous ${opName} submission was rejected; its signed envelope stays valid until ledger time ${blocker.maxTime}; wait until about two minutes after that before a new attempt`);",
`  const blocker = store.blocking(st, opName);
  if (blocker) {
    // a rejected envelope may still be valid; a new attempt waits until the NETWORK shows its window has closed
    let g; try { g = await rpc.getTransaction(blocker.txHash); } catch { refuse(\`cannot reach the RPC to verify that the rejected \${opName} envelope has expired; no new attempt was made\`); }
    if (g && (g.status === 'SUCCESS' || g.status === 'FAILED')) refuse(\`the chain shows the rejected \${opName} transaction as included (status \${g.status}); manual review is needed; no new attempt was made\`);
    const v = windowClosedByNetwork(blocker, g, (deps.now || nowDefault)());
    if (!v.closed) refuse(\`a previous \${opName} submission was rejected and its window cannot yet be proven closed: \${v.why}; no new attempt was made\`);
    store.resolveRejected(cfg, opName, blocker.txHash, (deps.now || nowDefault)());
  }`],
  ['intentText, prepare, preview, reconcile, execute, classifySubmission, pollTransaction,', 'intentText, prepare, preview, reconcile, execute, classifySubmission, pollTransaction, windowClosedByNetwork,'],
]);

// ---------------- state store ----------------
let s = fs.readFileSync('state-store.cjs', 'utf8');
const a0 = s.indexOf('function bestEffortOwnerOnly'); const a1 = s.indexOf('function createStore');
if (a0 < 0 || a1 < 0) throw new Error('store anchors');
const acl = `// ---------- owner-only permission: applied AND verified by inspecting the resulting ACL ----------
// Windows: the ACL is set with icacls using the user's SID (not a name that could be ambiguous), inheritance is removed, and then
// the real ACL is read back with PowerShell/.NET (SIDs, so no dependence on the display language). The file counts as owner-only only
// if: inheritance is blocked, exactly one rule exists, it is an explicit Allow of FullControl for the current user's SID, and the
// file's owner is that SID. A failure of any step is an error (the caller refuses); the exit code of icacls is never trusted alone.
// Other platforms: mode 0600 is applied and the mode bits are checked.
const ACL_INSPECT_SCRIPT = [
  '$p = $env:TOBIN_ACL_PATH',
  '$acl = Get-Acl -LiteralPath $p',
  '$me = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value',
  '$rules = @($acl.GetAccessRules($true, $true, [Security.Principal.SecurityIdentifier]) | ForEach-Object { [pscustomobject]@{ sid = $_.IdentityReference.Value; type = [string]$_.AccessControlType; rights = [string]$_.FileSystemRights; inherited = [bool]$_.IsInherited } })',
  '[pscustomobject]@{ me = $me; owner = $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value; protected = [bool]$acl.AreAccessRulesProtected; rules = $rules } | ConvertTo-Json -Compress -Depth 4',
].join('; ');

function inspectAcl(file, exec = execFileSync, env = process.env) {
  let out;
  try { out = exec('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ACL_INSPECT_SCRIPT], { encoding: 'utf8', windowsHide: true, env: { ...env, TOBIN_ACL_PATH: file } }); }
  catch { throw new StateError('could not inspect the file ACL'); }
  let a; try { a = JSON.parse(out); } catch { throw new StateError('the ACL inspection returned an unreadable answer'); }
  if (!a || typeof a.me !== 'string' || !Array.isArray(a.rules)) throw new StateError('the ACL inspection returned an unexpected shape');
  return a;
}

/** Pure judgement of an inspected ACL. */
function evaluateOwnerOnly(a) {
  const problems = [];
  if (a.protected !== true) problems.push('inheritance is not blocked');
  if (a.owner !== a.me) problems.push('the file owner is not the current user');
  if (a.rules.length !== 1) problems.push(\`\${a.rules.length} access rules present (expected exactly 1)\`);
  for (const r of a.rules) {
    if (r.sid !== a.me) problems.push('a rule grants access to another principal');
    if (r.type !== 'Allow') problems.push('a rule is not an Allow rule');
    if (r.inherited) problems.push('a rule is inherited');
    if (!/FullControl/.test(String(r.rights))) problems.push('the user rule is not FullControl');
  }
  return { ok: problems.length === 0, problems };
}

function verifyOwnerOnly(file, { platform = process.platform, exec = execFileSync, fs = nodeFs } = {}) {
  if (platform !== 'win32') {
    if ((fs.statSync(file).mode & 0o077) !== 0) throw new StateError('file mode allows access to group or others');
    return { applied: true, how: 'posix mode 0600, verified' };
  }
  const v = evaluateOwnerOnly(inspectAcl(file, exec));
  if (!v.ok) throw new StateError(\`owner-only access is not in place: \${v.problems.join('; ')}\`);
  return { applied: true, how: 'ACL inspected: single explicit FullControl rule for the current user' };
}

function restrictOwnerOnly(file, { platform = process.platform, exec = execFileSync, fs = nodeFs } = {}) {
  if (platform !== 'win32') { fs.chmodSync(file, 0o600); return verifyOwnerOnly(file, { platform, exec, fs }); }
  const me = inspectAcl(file, exec).me;
  try { exec('icacls', [file, '/inheritance:r', '/grant:r', \`*\${me}:(F)\`], { stdio: 'ignore', windowsHide: true }); }
  catch { throw new StateError('icacls failed; owner-only access could not be applied'); }
  return verifyOwnerOnly(file, { platform, exec, fs });   // the outcome is judged from the real ACL, not from the exit code
}
restrictOwnerOnly.verify = verifyOwnerOnly;

`;
s = s.slice(0, a0) + acl + s.slice(a1);
fs.writeFileSync('state-store.cjs', s);
edit('state-store.cjs', [
  ["const REASONS = ['ON_CHAIN_FAILED', 'SUBMISSION_REJECTED', 'WINDOW_PASSED_NOT_FOUND'];", "const REASONS = ['ON_CHAIN_FAILED', 'SUBMISSION_REJECTED', 'SUBMISSION_REJECTED_WINDOW_CLOSED', 'WINDOW_PASSED_NOT_FOUND'];"],
  ['restrict = bestEffortOwnerOnly } = {}) {', 'restrict = restrictOwnerOnly } = {}) {'],
  ["    let back;\n    try { back = fs.readFileSync(file, 'utf8'); }", "    if (typeof restrict.verify === 'function') {\n      try { restrict.verify(file); } catch (e) { throw new StateError(`state written but owner-only access could not be confirmed: ${e.message}`); }\n    }\n    let back;\n    try { back = fs.readFileSync(file, 'utf8'); }"],
  ["  function blocking(state, op, now, margin = 120) {\n    return state.operations.find((o) => o.operation === op && o.status === 'FAILED' && o.reason === 'SUBMISSION_REJECTED' && now <= o.maxTime + margin);\n  }",
   "  function blocking(state, op) {\n    return state.operations.find((o) => o.operation === op && o.status === 'FAILED' && o.reason === 'SUBMISSION_REJECTED');\n  }\n\n  /** Called only after the network has shown that the rejected envelope's validity window is closed. */\n  function resolveRejected(cfg, op, txHash, now) {\n    const state = assertMatches(cfg);\n    const rec = state.operations.find((o) => o.operation === op && o.txHash === txHash && o.status === 'FAILED' && o.reason === 'SUBMISSION_REJECTED');\n    if (!rec) throw new StateError('no rejected record to resolve');\n    rec.reason = 'SUBMISSION_REJECTED_WINDOW_CLOSED'; rec.updatedAt = new Date(now * 1000).toISOString();\n    return writeAtomic(state);\n  }"],
  ['return { load, init, assertMatches, markPending, markResult, annotate, blocking, active, writeAtomic };', 'return { load, init, assertMatches, markPending, markResult, annotate, blocking, resolveRejected, active, writeAtomic };'],
  ['module.exports = { createStore, validateState, StateError, bestEffortOwnerOnly, OPS, STATUSES, REASONS, SUBMISSIONS };', 'module.exports = { createStore, validateState, StateError, restrictOwnerOnly, verifyOwnerOnly, inspectAcl, evaluateOwnerOnly, OPS, STATUSES, REASONS, SUBMISSIONS };'],
]);

// ---------------- DPAPI test seam (environment only; the CLI never passes it) ----------------
edit('dpapi-key.cjs', [
  ['function decryptWithDpapi() {', 'function decryptWithDpapi(opts = {}) {'],
  ["{ encoding: 'buffer', stdio: ['ignore', 'pipe', 'ignore'], windowsHide: true });", "{ encoding: 'buffer', stdio: ['ignore', 'pipe', 'ignore'], windowsHide: true, env: opts.env || process.env });"],
]);
console.log('patched');
