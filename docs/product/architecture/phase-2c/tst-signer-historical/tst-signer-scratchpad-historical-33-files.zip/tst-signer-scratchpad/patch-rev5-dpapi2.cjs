const fs = require('fs');
let t = fs.readFileSync('dpapi-key.cjs', 'utf8');
const a = "  '    if ($bstr.ToInt64() -ne 0) { & $FreeBstr $bstr }',\n  '    $Secure.Dispose()',";
if (!t.includes(a)) throw new Error('anchor');
t = t.replace(a, () => "  '    try { if ($bstr.ToInt64() -ne 0) { & $FreeBstr $bstr } } finally { $Secure.Dispose() }',");
fs.writeFileSync('dpapi-key.cjs', t);
console.log('nested cleanup');
