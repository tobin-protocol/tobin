'use strict';
const fs = require('fs');
// ---- an ordering test: a malicious simulation must be rejected BEFORE any transaction is assembled from it ----
let t = fs.readFileSync('test/authorization.test.cjs', 'utf8');
t += `
test('a malicious simulation is refused before assembly: no transaction is ever assembled from entries the specification does not approve', async () => {
  const real = S.rpc.assembleTransaction; let assembled = 0;
  S.rpc.assembleTransaction = (...a) => { assembled++; return real(...a); };
  try {
    for (const op of OPS) {
      const m = makeDeps(op, { rpcOver: { auth: evil['nested invocation'](op) } });
      await rejects(core.preview(m.deps, cfg, op), /authorization/);
    }
    assert.equal(assembled, 0, 'assembleTransaction must not run for a rejected simulation');
    await core.preview(makeDeps('mint-C').deps, cfg, 'mint-C');
    assert.equal(assembled, 1, 'the spy works: an approved simulation is assembled exactly once');
  } finally { S.rpc.assembleTransaction = real; }
});
`;
fs.writeFileSync('test/authorization.test.cjs', t);

// ---- mutation harness ----
let m = fs.readFileSync('mutate.cjs', 'utf8');
const rep = (a, b) => { if (!m.includes(a)) throw new Error('missing: ' + a.slice(0, 80)); m = m.replace(a, () => b); };
rep("const D = 'dpapi-key.cjs';\nconst orig = { [C]: fs.readFileSync(C, 'utf8'), [T]: fs.readFileSync(T, 'utf8'), [D]: fs.readFileSync(D, 'utf8') };",
    "const D = 'dpapi-key.cjs'; const AZ = 'authorization.cjs';\nconst orig = { [C]: fs.readFileSync(C, 'utf8'), [T]: fs.readFileSync(T, 'utf8'), [D]: fs.readFileSync(D, 'utf8'), [AZ]: fs.readFileSync(AZ, 'utf8') };");
rep("const FAST = ['test/tst-signer.test.cjs', 'test/hardening.test.cjs', 'test/submission.test.cjs', 'test/expiry.test.cjs'];",
    "const FAST = ['test/tst-signer.test.cjs', 'test/hardening.test.cjs', 'test/submission.test.cjs', 'test/expiry.test.cjs', 'test/authorization.test.cjs'];");
rep("const WIN = ['test/windows.test.cjs'];", "const WIN = ['test/windows.test.cjs', 'test/dpapi-cleanup.test.cjs'];");
rep("for (const f of [C, T, D]) fs.writeFileSync(f, orig[f]);", "for (const f of [C, T, D, AZ]) fs.writeFileSync(f, orig[f]);");
rep("if (base.fail !== 0 || base.pass < 100)", "if (base.fail !== 0 || base.pass < 130)");
const Z = (a, b, l, s) => `  [AZ, ${JSON.stringify(a)}, ${JSON.stringify(b)}, ${JSON.stringify(l)}${s ? `, '${s}'` : ''}],`;
const K = (a, b, l, s) => `  [C, ${JSON.stringify(a)}, ${JSON.stringify(b)}, ${JSON.stringify(l)}${s ? `, '${s}'` : ''}],`;
const P = (a, b, l) => `  [D, ${JSON.stringify(a)}, ${JSON.stringify(b)}, ${JSON.stringify(l)}, 'win'],`;
const add = [
  // entry set
  Z("if (entries.length < expected.length) fail(", "if (false) fail(", 'auth: missing entry accepted'),
  Z("if (entries.length > expected.length) {", "if (false) {", 'auth: additional entries accepted'),
  Z("const dup = decoded.some((d, i) => d !== null && decoded.indexOf(d) !== i);", "const dup = false;", 'auth: duplicates not recognised'),
  Z("if (!Array.isArray(entries)) fail(", "if (false) fail(", 'auth: non-list accepted'),
  // credentials
  Z("if (kind !== 'sorobanCredentialsSourceAccount') fail(", "if (false) fail(", 'auth: any credential kind accepted'),
  // decoding
  Z("if (entry.toXDR('base64') !== b64) fail(", "if (false) fail(", 'auth: non-canonical encoding accepted'),
  // description of the tree
  Z("if (depth > MAX_DEPTH) fail(", "if (false) fail(", 'auth: depth guard removed'),
  Z("requireKeys(inv, ['function', 'subInvocations'], `${path} invocation`);", "", 'auth: invocation fields not checked'),
  Z("if (!Array.isArray(inv.subInvocations)) fail(", "if (false) fail(", 'auth: non-list sub-invocations accepted'),
  Z("requireKeys(c, ['contractAddress', 'functionName', 'args'], `${path} contract call`);", "", 'auth: contract-call fields not checked'),
  Z("addressOf(S, c.contractAddress, `${path} contract`, /^C/)", "addressOf(S, c.contractAddress, `${path} contract`, /^[GC]/)", 'auth: an account accepted as the contract'),
  Z("subs: inv.subInvocations.map((s, i) => describeInvocation(S, s, depth + 1, `${path}.sub[${i}]`))", "subs: []", 'auth: nested invocations ignored'),
  Z("if (!pre || pre.type !== 'contractIdPreimageFromAddress') fail(", "if (false) fail(", 'auth: other preimage kinds accepted'),
  Z("if (!ex || ex.type !== 'contractExecutableWasm') fail(", "if (false) fail(", 'auth: other executable kinds accepted'),
  Z("} else fail(`${path} function kind is not supported (${f && f.type})`);", "} else fn = { kind: 'other' };", 'auth: unknown function kinds accepted'),
  Z("c.args.map((a, i) => describeScVal(S, a, `${path} argument ${i}`))", "[]", 'auth: contract-call arguments ignored'),
  Z("a.constructorArgs.map((v, i) => describeScVal(S, v, `${path} constructor argument ${i}`))", "[]", 'auth: constructor arguments ignored'),
  Z("name: Buffer.from(bytesOf(c.functionName, `${path} function name`)).toString('utf8')", "name: 'mint'", 'auth: function name assumed'),
  Z("salt: bytesOf(pre.fromAddress.salt, 'salt').toString('hex')", "salt: ''", 'auth: salt ignored'),
  Z("wasm: bytesOf(ex.wasmHash, 'Wasm hash').toString('hex')", "wasm: ''", 'auth: Wasm hash ignored'),
  Z("deployer: addressOf(S, pre.fromAddress.address, `${path} deployer`, /^G/)", "deployer: ''", 'auth: deployer ignored'),
  // values
  Z("case 'scvAddress': return { t: 'address', v: addressOf(S, v.address, what, /^[GC]/) };", "case 'scvAddress': return { t: 'address', v: '' };", 'auth: address argument value ignored'),
  Z("return { t: 'i128', v: BigInt(n).toString() };", "return { t: 'i128', v: '0' };", 'auth: i128 value ignored'),
  Z("case 'scvU32': return { t: 'u32', v: Number(v.u32) };", "case 'scvU32': return { t: 'u32', v: 0 };", 'auth: u32 value ignored'),
  Z("case 'scvString': return { t: 'string', v: Buffer.from(bytesOf(v.str, what)).toString('utf8') };", "case 'scvString': return { t: 'string', v: '' };", 'auth: string value ignored'),
  Z("default: return fail(`${what} has an unsupported value type (${v.type})`);", "default: return { t: v.type, v: '' };", 'auth: unknown value types accepted'),
  // comparison layers
  Z("if (diff) fail(`entry ${i} differs from the approved invocation at ${diff}`);", "if (false) fail(`entry ${i} differs from the approved invocation at ${diff}`);", 'auth: structural comparison skipped'),
  Z("if (actualB64 !== expectedEntry.toXDR('base64')) fail(", "if (false) fail(", 'auth: canonical-bytes comparison skipped'),
  Z("if (a.length !== b.length) return `${path}.length`;", "", 'auth: list lengths not compared'),
  Z("if (ka.join() !== kb.join()) return `${path}{fields}`;", "", 'auth: object fields not compared'),
  Z("if (typeof a !== typeof b) return path || 'value';", "", 'auth: value types not compared'),
  // the specification
  Z("return [buildExpectedAuthEntry(S, { kind: 'mint', contract: cfg.tokenId, to: cfg.C, amount: cfg.mintC })];", "return [buildExpectedAuthEntry(S, { kind: 'mint', contract: cfg.tokenId, to: cfg.D, amount: cfg.mintC })];", 'auth: expectation uses the wrong recipient'),
  Z("return [buildExpectedAuthEntry(S, { kind: 'mint', contract: cfg.tokenId, to: cfg.D, amount: cfg.mintD })];", "return [buildExpectedAuthEntry(S, { kind: 'mint', contract: cfg.tokenId, to: cfg.D, amount: cfg.mintC })];", 'auth: expectation uses the wrong amount'),
  Z("return fail(`no authorization specification exists for operation", "return [] || fail(`no authorization specification exists for operation", 'auth: unknown operations get an empty expectation'),
  Z("functionName: 'mint', args:", "functionName: 'transfer', args:", 'auth: expectation names the wrong function'),
  // integration in the core
  K("if (assembled) validateAuthorizationEntries(S, cfg, opName, auth);", "", 'core: assembled transaction authorization not validated'),
  K("validateAuthorizationEntries(S, cfg, opName, sim.result.auth);", "", 'core: simulated authorization not validated before assembly'),
  // BSTR cleanup
  P("try { if ($bstr.ToInt64() -ne 0) { & $FreeBstr $bstr } } finally { $Secure.Dispose() }", "try { if ($bstr.ToInt64() -ne 0) { } } finally { $Secure.Dispose() }", 'dpapi: BSTR never freed'),
  P("if ($bstr.ToInt64() -ne 0) { & $FreeBstr $bstr }", "if ($true) { & $FreeBstr $bstr }", 'dpapi: free attempted even when nothing was allocated'),
  P("finally { $Secure.Dispose() }", "finally { }", 'dpapi: SecureString never disposed'),
  P("try { if ($bstr.ToInt64() -ne 0) { & $FreeBstr $bstr } } finally { $Secure.Dispose() }", "if ($bstr.ToInt64() -ne 0) { & $FreeBstr $bstr }; $Secure.Dispose()", 'dpapi: disposal skipped when the free step fails'),
  P("[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($p)", "[Runtime.InteropServices.Marshal]::FreeBSTR($p)", 'dpapi: non-zeroing free'),
  P("[Runtime.InteropServices.Marshal]::PtrToStringBSTR($p)", "[Runtime.InteropServices.Marshal]::PtrToStringAuto($p)", 'dpapi: wrong conversion call'),
  P("'  try {',\n  '    $bstr = & $ToBstr $Secure',\n  '    return (& $BstrToString $bstr)',\n  '  } finally {',", "'  $bstr = & $ToBstr $Secure',\n  '  try {',\n  '    return (& $BstrToString $bstr)',\n  '  } finally {',", 'dpapi: allocation moved outside the protected block (still freed)'),
].join('\n');
rep('const M = [\n', 'const M = [\n' + add + '\n');
fs.writeFileSync('mutate.cjs', m);
console.log('tests added, harness extended');
