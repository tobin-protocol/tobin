'use strict';
const fs = require('fs');
let t = fs.readFileSync('dpapi-key.cjs', 'utf8');
const i = t.indexOf('// The PowerShell text is a constant'); const j = t.indexOf('/** Default decryptor');
if (i < 0 || j < 0) throw new Error('anchors');
const block = `// The PowerShell text is a constant: it contains no secret and no caller-controlled value. The file name is fixed.
//
// BSTR cleanup (revision 5). Converting a SecureString to plain text goes through an unmanaged BSTR. \`Read-TobinSecret\` allocates it
// with SecureStringToBSTR and, in a \`finally\` block, ALWAYS zeroes and frees it with ZeroFreeBSTR, on success and on every failure after
// the allocation (nothing is freed if the allocation itself failed, because nothing was allocated), and disposes the SecureString.
// The three unmanaged operations are replaceable script blocks only so that the cleanup can be tested with instrumented fakes; the
// production call uses the defaults. The plain-text string that PowerShell returns is a managed string and cannot be erased on demand;
// it travels to the parent process through the stdout pipe only.
const DPAPI_FUNCTION = [
  'function Read-TobinSecret {',
  '  param([Parameter(Mandatory = $true)][System.Security.SecureString]$Secure,',
  '        [scriptblock]$ToBstr = { param($s) [Runtime.InteropServices.Marshal]::SecureStringToBSTR($s) },',
  '        [scriptblock]$BstrToString = { param($p) [Runtime.InteropServices.Marshal]::PtrToStringBSTR($p) },',
  '        [scriptblock]$FreeBstr = { param($p) [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($p) })',
  '  $bstr = [IntPtr]::Zero',
  '  try {',
  '    $bstr = & $ToBstr $Secure',
  '    return (& $BstrToString $bstr)',
  '  } finally {',
  '    if ($bstr.ToInt64() -ne 0) { & $FreeBstr $bstr }',
  '    $Secure.Dispose()',
  '  }',
  '}',
].join('\\n');

const DPAPI_SCRIPT = DPAPI_FUNCTION + '\\n' +
  "$f = Join-Path $env:LOCALAPPDATA 'TobinTestKeys\\\\settlement-token-admin.dpapi'; " +
  '$s = (Get-Content -Raw $f).Trim() | ConvertTo-SecureString; ' +
  'Read-TobinSecret -Secure $s';

`;
t = t.slice(0, i) + block + t.slice(j);
t = t.replace("const { redact } = require('./tst-signer-core.cjs');", "const { redact } = require('./refusal.cjs');");
t = t.replace('module.exports = { loadAdminKey, decryptWithDpapi, DPAPI_SCRIPT };', 'module.exports = { loadAdminKey, decryptWithDpapi, DPAPI_SCRIPT, DPAPI_FUNCTION };');
fs.writeFileSync('dpapi-key.cjs', t);
console.log('dpapi patched');
