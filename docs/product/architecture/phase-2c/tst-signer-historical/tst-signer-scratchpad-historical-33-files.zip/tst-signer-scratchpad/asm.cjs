const {loadSdk}=require('./sdk-loader.cjs');const S=loadSdk();const fs=require('fs');
const M=JSON.parse(fs.readFileSync('C:/Users/Ebubechi/Documents/codes/scf/tobin-protocol/tobin/contracts/deployments/testnet.json','utf8'));
const pub=JSON.parse(fs.readFileSync(process.env.LOCALAPPDATA+'/TobinTestKeys/pub.json','utf8'));
(async()=>{const srv=new S.rpc.Server(M.rpc);const acc=await srv.getAccount(pub.A);
const tx=new S.TransactionBuilder(acc,{fee:'100',networkPassphrase:M.networkPassphrase}).addOperation(new S.Contract(M.contracts.tobin_test_token.contractId).call('name')).setTimeout(30).build();
const sim=await srv.simulateTransaction(tx);
console.log('sim keys',Object.keys(sim).join(','),'| td ctor',sim.transactionData&&sim.transactionData.constructor.name);
try{const a=S.rpc.assembleTransaction(tx,sim).build();console.log('assemble OK, fee',a.fee,'ops',a.operations.length);}catch(e){console.log('assemble FAIL',String(e).slice(0,160));}
const b=sim.transactionData.build();console.log('build() ctor',b.constructor.name,Object.getOwnPropertyNames(Object.getPrototypeOf(b)).slice(0,6), typeof b.toXdr, typeof b.toXDR);})();
