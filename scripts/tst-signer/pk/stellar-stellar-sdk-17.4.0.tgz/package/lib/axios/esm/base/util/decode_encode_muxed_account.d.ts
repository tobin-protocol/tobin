import { MuxedAccount } from "../../xdr/index.js";
export declare function canonicalUint64Id(id: string): string;
/**
 * Converts a Stellar address (in G... or M... form) to an `xdr.MuxedAccount`
 * structure, using the ed25519 representation when possible.
 *
 * This supports full muxed accounts, where an `M...` address will resolve to
 * both its underlying `G...` address and an integer ID.
 *
 * @param address - G... or M... address to encode into XDR
 */
export declare function decodeAddressToMuxedAccount(address: string): MuxedAccount;
/**
 * Converts an xdr.MuxedAccount to its StrKey representation.
 *
 * Returns the "M..." string representation if there is a muxing ID within
 * the object, or the "G..." representation otherwise.
 *
 * @param muxedAccount - raw account to stringify
 *
 * @see https://stellar.org/protocol/sep-23
 */
export declare function encodeMuxedAccountToAddress(muxedAccount: MuxedAccount): string;
/**
 * Transform a Stellar address (G...) and an ID into its XDR representation.
 *
 * @param address - a Stellar G... address
 * @param id - the ID, as a uint64 in decimal digits. Leading zeros are
 *     removed. At most 22 digits.
 */
export declare function encodeMuxedAccount(address: string, id: string): MuxedAccount;
/**
 * Transform a contract address (C...) and an ID into a muxed contract
 * address (W...).
 *
 * @param contractId - a contract C... address
 * @param id - the ID, as a uint64 in decimal digits. Leading zeros are
 *     removed. At most 22 digits.
 */
export declare function encodeMuxedContractAddress(contractId: string, id: string): string;
/**
 * Extracts the base address from a muxed address: G... from M..., or C...
 * from W.... A G... or C... address is returned unchanged.
 * @param address - an account (G... or M...) or contract (C... or W...)
 *     address
 */
export declare function extractBaseAddress(address: string): string;
